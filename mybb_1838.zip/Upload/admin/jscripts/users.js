var Users = {
	last_value: '',
	cached_users: '',

	init: function()
	{
	}
};

$(function()
{
	Users.init();
});